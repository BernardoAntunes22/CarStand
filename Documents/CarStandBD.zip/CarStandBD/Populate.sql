/* CarStand
	Elementos da Equipa:
		-Bernardo Antunes: 50037271
        -Bernardo Branco: 50039074
*/


/*POPULATE COD_POST*/


INSERT INTO Código_Postal VALUES (30, 'Lisboa', '240', '1200', 'Lisboa');
INSERT INTO Código_Postal VALUES (300, 'Lisboa', '340', '1400', 'Santa Maria de Belém');
INSERT INTO Código_Postal VALUES (301, 'Lisboa', '354', '1400', 'Santa Maria de Belém');
INSERT INTO Código_Postal VALUES (302, 'Lisboa', '355', '1400', 'Santa Maria de Belém');
INSERT INTO Código_Postal VALUES (303, 'Lisboa', '260', '1400', 'Santa Maria de Belém');
INSERT INTO Código_Postal VALUES (304, 'Lisboa', '138', '1400', 'Santa Maria de Belém');
INSERT INTO Código_Postal VALUES (305, 'Lisboa', '307', '1400', 'Santa Maria de Belém');
INSERT INTO Código_Postal VALUES (306, 'Lisboa', '354', '1400', 'Santa Maria de Belém');
INSERT INTO Código_Postal VALUES (307, 'Lisboa', '308', '1400', 'Santa Maria de Belém');
INSERT INTO Código_Postal VALUES (308, 'Lisboa', '057', '1400', 'Santa Maria de Belém');
INSERT INTO Código_Postal VALUES (309, 'Lisboa', '096', '1400', 'Santa Maria de Belém');
INSERT INTO Código_Postal VALUES (310, 'Lisboa', '871', '1200', 'Santos-o-Velho');
INSERT INTO Código_Postal VALUES (311, 'Lisboa', '011', '1200', 'Santos-o-Velho');
INSERT INTO Código_Postal VALUES (312, 'Lisboa', '084', '1200', 'Santos-o-Velho');
INSERT INTO Código_Postal VALUES (313, 'Lisboa', '014', '1200', 'Santos-o-Velho');
INSERT INTO Código_Postal VALUES (314, 'Lisboa', '868', '1200', 'Santos-o-Velho');
INSERT INTO Código_Postal VALUES (315, 'Lisboa', '013', '1200', 'Santos-o-Velho');
INSERT INTO Código_Postal VALUES (316, 'Lisboa', '149', '1200', 'Santos-o-Velho');
INSERT INTO Código_Postal VALUES (317, 'Lisboa', '615', '1200', 'Santos-o-Velho');
INSERT INTO Código_Postal VALUES (318, 'Lisboa', '721', '1200', 'Santos-o-Velho');
INSERT INTO Código_Postal VALUES (319, 'Lisboa', '868', '1200', 'Santos-o-Velho');
INSERT INTO Código_Postal VALUES (320, 'Lisboa', '174', '1300', 'Ajuda');
INSERT INTO Código_Postal VALUES (321, 'Lisboa', '435', '1300', 'Ajuda');
INSERT INTO Código_Postal VALUES (322, 'Lisboa', '211', '1300', 'Ajuda');
INSERT INTO Código_Postal VALUES (323, 'Lisboa', '563', '1300', 'Ajuda');
INSERT INTO Código_Postal VALUES (324, 'Lisboa', '495', '1300', 'Ajuda');
INSERT INTO Código_Postal VALUES (325, 'Lisboa', '325', '1300', 'Ajuda');
INSERT INTO Código_Postal VALUES (326, 'Lisboa', '177', '1300', 'Ajuda');
INSERT INTO Código_Postal VALUES (327, 'Lisboa', '573', '1300', 'Ajuda');
INSERT INTO Código_Postal VALUES (328, 'Lisboa', '379', '1300', 'Ajuda');
INSERT INTO Código_Postal VALUES (329, 'Lisboa', '333', '1300', 'Ajuda');
INSERT INTO Código_Postal VALUES (330, 'Lisboa', '067', '1300', 'Ajuda');
INSERT INTO Código_Postal VALUES (331, 'Lisboa', '392', '1300', 'Ajuda');
INSERT INTO Código_Postal VALUES (332, 'Lisboa', '451', '1300', 'Ajuda');
INSERT INTO Código_Postal VALUES (333, 'Lisboa', '223', '1100', 'Castelo');
INSERT INTO Código_Postal VALUES (334, 'Lisboa', '477', '1100', 'Castelo');
INSERT INTO Código_Postal VALUES (335, 'Lisboa', '129', '1100', 'Castelo');
INSERT INTO Código_Postal VALUES (336, 'Lisboa', '250', '1100', 'Castelo');
INSERT INTO Código_Postal VALUES (337, 'Lisboa', '479', '1100', 'Castelo');
INSERT INTO Código_Postal VALUES (338, 'Lisboa', '430', '1100', 'Castelo');
INSERT INTO Código_Postal VALUES (339, 'Lisboa', '181', '1100', 'Castelo');
INSERT INTO Código_Postal VALUES (340, 'Lisboa', '244', '1100', 'Castelo');
INSERT INTO Código_Postal VALUES (341, 'Lisboa', '245', '1100', 'Castelo');
INSERT INTO Código_Postal VALUES (342, 'Lisboa', '429', '1100', 'Castelo');





/*POPULATE CARROS*/

INSERT INTO Carro VALUES (400, 'Peugeot',	 '308', 	 '1500', '16700', '2018', 'hatchback', '69-Vz-71', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (401, 'Peugeot',	 '3008',	 '1600', '28890', '2019', 'SUV', '22-Zn-98', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (402, 'Peugeot',	 '308 SW',	 '1600', '18240', '2018', 'Carrinha', '11-QF-13', ' Diesel', 'Disponivel');
INSERT INTO Carro VALUES (403, 'Peugeot',	 '5088',	 '2000', '21900', '2016', 'SUV', '43-PU-34', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (404, 'Peugeot',	 '208',		 '1500', '28475', '2016', 'Hatchback', '56-RA-19', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (405, 'Peugeot',	 '508',	 	 '1500', '48953', '2019', 'Sedan', '97-ZF-67', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (406, 'Peugeot',	 '2008', 	 '1500', '29484', '2018', 'SUV', '83-UT-29', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (407, 'Peugeot',	 '208', 	 '1200', '18475', '2019', 'Hatchback', '98-ZA-48', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (408, 'Peugeot',	 '208',		 '1600', '28475', '2017', 'Hatchback', '34-SI-76', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (409, 'Peugeot',	 '3008',	 '2000', '19485', '2017', 'SUV', '76-SQ-93', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (410, 'Audi',		 'A4',		 '2000', '28950', '2016', 'Carrinha', '59-QE-89', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (411, 'Audi',		 'A3',		 '999', '22900', '2018', 'Hatchback', '45-UD-58', 'Gasolina', 'Disponivel');
INSERT INTO Carro VALUES (412, 'Audi',		 'A5',		 '2000', '25950', '2016', 'Sedan', '23-QO-56', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (413, 'Audi',	 	'Q7',		 '2957', '69900', '2017', 'SUV', '40-TL-20', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (414, 'Audi',	 	'Q2',		 '1598', '24390', '2017', 'SUV', '51-TM-19', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (415, 'Audi',	 	'A6',		 '1968', '35990', '2016', 'Carrinha', '63-SB-57', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (416, 'Audi',	 	'A4',		 '2000', '24500', '2016', 'Carrinha', '23-QF-45', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (417, 'Audi',	 	'A1',		 '1400', '16950', '2016', 'Hatchback', '48-QS-89', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (418, 'Audi',	 	'A7',		 '3000', '67948', '2019', 'Sedan', '48-ZM-28', 'Gasolina', 'Disponivel');
INSERT INTO Carro VALUES (419, 'Audi',	 	'A1',		 '1200', '14790', '2016', 'Hatchback', '38-PS-48', ' Diesel', 'Disponivel');
INSERT INTO Carro VALUES (420, 'Audi',	 	'A3',		 '1600', '18463', '2018', 'Hatchback', '85-VT-83', 'Diesel', 'Disponivel');
INSERT INTO Carro VALUES (421, 'Audi',	 	'A1',		 '1100', '14500', '2017', 'Hatchback', '93-TB_82', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (422, 'Peugeot', 	'308',		 '1500', '16700', '2018', 'hatchback', '69-VB-71', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (423, 'Peugeot', 	'3008',	 	 '1600', '28890', '2019', 'SUV', '22-ZD-98', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (424, 'Peugeot', 	'308 SW',	 '1600', '18240', '2018', 'Carrinha', '71-QF-12', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (425, 'Peugeot', 	'5088',	 	 '2000', '21900', '2016', 'SUV', '43-QI-34', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (426, 'Peugeot',	'208',		 '1500', '28475', '2016', 'Hatchback', '56-SO-19', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (427, 'Peugeot',	'508',		 '1500', '48953', '2019', 'Sedan', '98-ZL-57', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (428, 'Peugeot', 	'2008',	 	 '1500', '29484', '2018', 'SUV', '83-WU-29', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (429, 'Peugeot', 	'208', 		 '1200', '18475', '2019', 'Hatchback', '98-ZB-48', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (430, 'Peugeot', 	'208', 		 '1600', '28475', '2017', 'Hatchback', '34-SG-76', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (431, 'Peugeot', 	'3008',		 '2000', '19485', '2017', 'SUV', '76-SN-93', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (432, 'Audi',	 	'A4',		 '2000', '28950', '2016', 'Carrinha', '59-QE-89', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (433, 'Audi',	 	'A3',		 '999', '22900', '2018', 'Hatchback', '45-UB-58', 'Gasolina', 'Reservado');
INSERT INTO Carro VALUES (434, 'Audi',	 	'A5',		 '2000','25950', '2016', 'Sedan', '23-QO-56', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (435, 'Audi',	 	'Q7',		 '2957', '69900', '2017', 'SUV', '40-TV-20', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (436, 'Audi',	 	'Q2',		 '1598', '24390', '2017', 'SUV', '51-TA-19', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (437, 'Audi',	 	'A6',		 '1968', '35990', '2016', 'Carrinha', '63-SB-57', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (438, 'Audi',	 	'A4',		 '2000', '24500', '2016', 'Carrinha', '23-QH-45', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (439, 'Audi',	 	'A1',		 '1400', '16950', '2016', 'Hactback', '48-QN-89', 'Diesel', 'Reservado');
INSERT INTO Carro VALUES (440, 'Audi',	 	'A7',		 '3000', '67948', '2019', 'Sedan', '48-ZN-28', 'Gasolina', 'Reservado');
INSERT INTO Carro VALUES (441, 'Audi',	 	'A1',		 '1200', '14790', '2016', 'Hatchback', '38-QR-48', ' Diesel', 'Vendido');
INSERT INTO Carro VALUES (442, 'Audi',	 	'A3',		 '1600', '18463', '2018', 'Hatchback', '85-VJ-83', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (443, 'Peugeot', 	'308',		 '1500', '16700', '2018', 'hatchback', '69-VH-71', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (444, 'Peugeot', 	'3008',		 '1600', '28890', '2019', 'SUV', '22-ZG-98', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (445, 'Peugeot', 	'308 SW',	 '1600', '18240', '2018', 'Carrinha', '71-QD-12', ' Diesel', 'Vendido');
INSERT INTO Carro VALUES (446, 'Peugeot', 	'5088',		 '2000', '21900', '2016', 'SUV', '43-QE-34', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (447, 'Peugeot', 	'208', 		 '1500', '28475', '2016', 'Hatchback', '56-SX-19', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (448, 'Peugeot', 	'508',		 '1500', '48953', '2019', 'Sedan', '98-ZI-57', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (449, 'Peugeot', 	'2008',		 '1500', '29484', '2018', 'SUV', '83-UZ-29', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (450, 'Peugeot', 	'208',		 '1200', '18475', '2019', 'Hatchback', '98-ZJ-48', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (451, 'Peugeot', 	'208',		 '1600', '28475', '2017', 'Hatchback', '34-SP-76', ' Diesel', 'Vendido');
INSERT INTO Carro VALUES (452, 'Peugeot', 	'3008',		 '2000', '19485', '2017', 'SUV', '76-SQ-93', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (453, 'Audi',	 	'A4',		 '2000', '28950', '2016', 'Carrinha', '59-QV-89', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (454, 'Audi',	 	'A3',		 '999', '22900', '2018', 'Hatchback', '45-UN-58', 'Gasolina', 'Vendido');
INSERT INTO Carro VALUES (455, 'Audi',	 	'A5',		 '2000', '25950', '2016', 'Sedan', '23-QE-56', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (456, 'Audi',	 	'Q7',		 '2957', '69900', '2017', 'SUV', '40-TO-20', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (457, 'Audi',	 	'Q2',		 '1598', '24390', '2017', 'SUV', '51-TP-19', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (458, 'Audi',	 	'A6',		 '1968', '35990', '2016', 'Carrinha', '63-SF-57', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (459, 'Audi',	 	'A4',		 '2000', '24500', '2016', 'Carrinha', '23-QG-45', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (460, 'Audi',	 	'A1',		 '1400', '16950', '2016', 'Hatchback', '48-QH-89', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (461, 'Audi',	 	'A7',		 '3000', '67948', '2019', 'Sedan', '48-ZZ-28', 'Gasolina', 'Vendido');
INSERT INTO Carro VALUES (462, 'Audi',	 	'A1',		 '1200', '14790', '2016', 'Hatchback', '38-QX-48', ' Diesel', 'Vendido');
INSERT INTO Carro VALUES (463, 'Audi',		'A3',		 '1600', '18463', '2018', 'Hatchback', '85-VJ-83', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (464, 'Peugeot',	'308',		 '1500', '16700', '2018', 'hatchback', '69-VR-71', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (465, 'Peugeot', 	'3008',		 '1600', '28890', '2019', 'SUV', '22-ZO-98', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (466, 'Peugeot', 	'308 SW',	 '1600', '18240', '2018', 'Carrinha', '71-QP-12', ' Diesel', 'Vendido');
INSERT INTO Carro VALUES (467, 'Peugeot', 	'5088',		 '2000', '21900', '2016', 'SUV', '43-QI-34', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (468, 'Peugeot', 	'208',		 '1500', '28475', '2016', 'Hatchback', '56-SE-19', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (469, 'Peugeot', 	'508',		 '1500', '48953', '2019', 'Sedan', '98-ZF-57', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (470, 'Peugeot', 	'2008',		 '1500', '29484', '2018', 'SUV', '83-UZ-29', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (471, 'Peugeot', 	'208',		 '1200', '18475', '2019', 'Hatchback', '98-ZV-48', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (472, 'Peugeot', 	'208', '1600', '28475', '2017', 'Hatchback', '34-SR-76', ' Diesel', 'Vendido');
INSERT INTO Carro VALUES (473, 'Peugeot', 	'3008', '2000', '19485', '2017', 'SUV', '76-ST-93', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (474, 'Audi',	 	'A4', '2000', '28950', '2016', 'Carrinha', '59-QU-89', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (475, 'Audi',	 	'A3', '999', '22900', '2018', 'Hatchback', '45-UI-58', 'Gasolina', 'Vendido');
INSERT INTO Carro VALUES (476, 'Audi',	 	'A5', '2000', '25950', '2016', 'Sedan', '23-QP-56', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (477, 'Audi',	 	'Q7', '2957', '69900', '2017', 'SUV', '40-TJ-20', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (478, 'Audi',	 	'Q2', '1598', '24390', '2017', 'SUV', '51-TH-19', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (479, 'Audi',	 	'A6', '1968', '35990', '2016', 'Carrinha', '63-SG-57', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (480, 'Audi',	 	'A4', '2000', '24500', '2016', 'Carrinha', '23-QD-45', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (481, 'Audi',	 	'A1', '1400', '16950', '2016', 'Hatchback', '48-QD-89', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (482, 'Audi',	 	'A7', '3000', '67948', '2019', 'Sedan', '48-ZI-28', 'Gasolina', 'Vendido');
INSERT INTO Carro VALUES (483, 'Audi',	 	'A1', '1200', '14790', '2016', 'Hatchback', '38-QT-48', ' Diesel', 'Vendido');
INSERT INTO Carro VALUES (484, 'Audi',	 	'A3', '1600', '18463', '2018', 'Hatchback', '85-VE-83', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (485, 'Peugeot', 	'308', '1500', '16700', '2018', 'hatchback', '69-UU-71', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (486, 'Peugeot', 	'3008', '1600', '28890', '2019', 'SUV', '22-ZS-98', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (487, 'Peugeot', 	'308 SW', '1600', '18240', '2018', 'Carrinha', '71-QF-12', ' Diesel', 'Vendido');
INSERT INTO Carro VALUES (488, 'Peugeot', 	'5088', '2000', '21900', '2016', 'SUV', '43-QU-34', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (489, 'Peugeot', 	'208', '1500', '28475', '2016', 'Hatchback', '56-SS-19', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (490, 'Peugeot', 	'508', '1500', '48953', '2019', 'Sedan', '98-ZT-57', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (491, 'Peugeot', 	'2008', '1500', '29484', '2018', 'SUV', '83-UO-29', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (492, 'Peugeot', 	'208', '1200', '18475', '2019', 'Hatchback', '98-ZP-48', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (493, 'Peugeot', 	'208', '1600', '28475', '2017', 'Hatchback', '34-SU-76', ' Diesel', 'Vendido');
INSERT INTO Carro VALUES (494, 'Peugeot', 	'3008', '2000', '19485', '2017', 'SUV', '76-SA-93', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (495, 'Audi',	 	'A4', '2000', '28950', '2016', 'Carrinha', '59-QB-89', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (496, 'Audi',	 	'A3', '999',  '22900', '2018', 'Hatchback', '45-UC-58', 'Gasolina', 'Vendido');
INSERT INTO Carro VALUES (497, 'Audi',	 	'A5', '2000', '25950', '2016', 'Sedan', '23-QM-56', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (498, 'Audi',	 	'Q7', '2957', '69900', '2017', 'SUV', '40-TG-20', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (499, 'Audi',	 	'Q2', '1598', '24390', '2017', 'SUV', '51-TB-19', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (500, 'Audi',	 	'A6', '1968', '35990', '2016', 'Carrinha', '63-SZ-57', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (501, 'Audi',	 	'A4', '2000', '24500', '2016', 'Carrinha', '23-QQ-45', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (502, 'Audi',	 	'A1', '1400', '16950', '2016', 'Hatchback', '48-QL-89', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (503, 'Audi',	 	'A7', '3000', '67948', '2019', 'Sedan', '48-ZU-28', 'Gasolina', 'Vendido');
INSERT INTO Carro VALUES (504, 'Audi',	 	'A1', '1200', '14790', '2016', 'Hatchback', '38-QE-47', ' Diesel', 'Vendido');
INSERT INTO Carro VALUES (505, 'Audi',	 	'A3', '1600', '18463', '2018', 'Hatchback', '85-VI-63', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (506, 'Peugeot', 	'2008', '1500', '29484', '2018', 'SUV', '83-XX-79', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (507, 'Peugeot', 	'208', '1200', '18475', '2019', 'Hatchback', '78-ZH-48', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (508, 'Peugeot', 	'208', '1600', '28475', '2017', 'Hatchback', '33-SI-76', ' Diesel', 'Vendido');
INSERT INTO Carro VALUES (509, 'Peugeot', 	'3008', '2000', '19485', '2017', 'SUV', '76-SU-33', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (510, 'Audi',	 	'A4', '2000', '28950', '2016', 'Carrinha', '59-QE-99', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (511, 'Audi',	 	'A3', '999',  '22900', '2018', 'Hatchback', '45-UB-55', 'Gasolina', 'Vendido');
INSERT INTO Carro VALUES (512, 'Audi',	 	'A5', '2000', '25950', '2016', 'Sedan',	 '23-QO-57', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (513, 'Audi',	 	'Q7', '2957', '69900', '2017', 'SUV', '40-TL-22', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (514, 'Audi',	 	'Q2', '1598', '24390', '2017', 'SUV', '55-TM-19', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (515, 'Audi',	 	'A6', '1968', '35990', '2016', 'Carrinha', '93-SB-57', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (516, 'Audi',	 	'A4', '2000', '24500', '2016', 'Carrinha', '21-QF-45', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (517, 'Audi',	 	'A1', '1400', '16950', '2016', 'Hatchback', '48-QD-09', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (518, 'Audi',	 	'A7', '3000', '67948', '2019', 'Sedan', '48-ZM-20', 'Gasolina', 'Vendido');
INSERT INTO Carro VALUES (519, 'Audi',	 	'A1', '1200', '14790', '2016', 'Hatchback', '08-QS-48', ' Diesel', 'Vendido');
INSERT INTO Carro VALUES (520, 'Audi',	 	'A3', '1600', '18463', '2018', 'Hatchback', '85-VU-03', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (521, 'Peugeot', 	'2008', '1500', '29484', '2018', 'SUV', '80-UU-29', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (522, 'Peugeot', 	'208', '1200', '18475', '2019', 'Hatchback', '90-ZA-08', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (523, 'Peugeot', 	'208', '1600', '28475', '2017', 'Hatchback', '34-SI-06', ' Diesel', 'Vendido');
INSERT INTO Carro VALUES (524, 'Peugeot', 	'3008', '2000', '19485', '2017', 'SUV', '07-SU-10', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (527, 'Audi',	 	'A5', '2000', '25950', '2016', 'Sedan', '23-QO-13', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (528, 'Audi',	 	'Q7', '2957', '69900', '2017', 'SUV', '08-TL-20', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (529, 'Audi',	 	'Q2', '1598', '24390', '2017', 'SUV', '51-TM-09', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (530, 'Audi',	 	'A6', '1968', '35990', '2016', 'Carrinha', '93-SB-57', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (531, 'Audi',	 	'A4', '2000', '24500', '2016', 'Carrinha', '20-QF-05', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (532, 'Audi',	 	'A1', '1400', '16950', '2016', 'Hatchback', '40-QD-80', 'Diesel', 'Vendido');
INSERT INTO Carro VALUES (533, 'Audi',	 	'A7', '3000', '67948', '2019', 'Sedan', '88-ZM-38', 'Gasolina', 'Vendido');
INSERT INTO Carro VALUES (534, 'Audi',	 	'A1', '1200', '14790', '2016', 'Hatchback', '78-QS-68', ' Diesel', 'Vendido');
INSERT INTO Carro VALUES (535, 'Audi',	 	'A3', '1600', '18463', '2018', 'Hatchback', '88-VU-43', 'Diesel', 'Vendido');





/*POPULATE STAND */

INSERT INTO Stand value (1,  'CarStand', 'CarStand@gmail.com', 213846325, 274567921, 'R. Rodrigues de Faria 8', 30);



/*POPULATE Colaborador */


INSERT INTO Colaborador values (51, 'Bernardo Antunes', 1);
INSERT INTO Colaborador values (52, 'Bernardo Branco', 1);
INSERT INTO Colaborador values (53, 'Diogo Sousa', 1);



/*POPULATE Cliente*/

INSERT INTO Cliente VALUES (200, 234567897, 'IgorSilva@gmail.com', 'Desempregado', 914564935, 'Rua Soldados da India', 'Igor Silva', 300);
INSERT INTO Cliente VALUES (201, 234567898, 'BenjaminLeonard@gmail.com', 'Gestor', 911269932, 'Rua 1', 'Benjamin Leonard', 301);
INSERT INTO Cliente VALUES (202, 234567899, 'MaciRogers@gmail.com', 'Diretor de Marketing', 935385823, 'Rua 1', 'MaciRogers', 302);
INSERT INTO Cliente VALUES (203, 234567900, 'LucilleDuarte@gmail.com', 'Web Designer', 924567823, 'Rua 11', 'Lucille Duarte', 303);
INSERT INTO Cliente VALUES (204, 234567901, 'SiobhanMarsden@gmail.com', 'Analísta', 969349672, 'Rua 12', 'Siobhan Marsden', 304);
INSERT INTO Cliente VALUES (205, 234567902, 'MikaelSantana@gmail.com', 'Gestor', 938732468, 'Rua 15', 'Mikael Santana', 305);
INSERT INTO Cliente VALUES (206, 234567903, 'HamzaWagstaff@gmail.com', 'Engenheiro Civil', 933573572, 'Rua 1', 'Hamza Wagstaff', 306);
INSERT INTO Cliente VALUES (207, 234567904, 'RishiMason@gmail.com', 'Engenheiro Informático', 933573555, 'Rua 15', 'Rishi Manson', 307);
INSERT INTO Cliente VALUES (208, 234567905, 'SalahuddinSnider@gmail.com', 'Desempregado', 933458927, 'Rua 14', 'Salahuddin Snider', 308);
INSERT INTO Cliente VALUES (209, 234567906, 'SapphireMcculloch@gmail.com', 'Engenheiro Civil', 933573572, 'Rua 16', 'Sapphire Mcculloch', 309);
INSERT INTO Cliente VALUES (210, 234567907, 'JarethEspinoza@gmail.com', 'Analista Informático', 933495849, 'Avenida 24 Julho', 'Jareth Espinoza', 310);
INSERT INTO Cliente VALUES (211, 234567908, 'DinaShelton@gmail.com', 'Gestor', 945642257, 'Travessa da água da flor', 'Dina Shelton', 311);
INSERT INTO Cliente VALUES (212, 234567909, 'AlayahHuang@gmail.com', 'Contabilista', 974367246, 'Travessa do Caldeira', 'Alayah Huang', 312);
INSERT INTO Cliente VALUES (213, 234567910, 'MaisyKirkland@gmail.com', 'Tecnico de manutenção', 956281345, 'Rua do Alecrim', 'Maisy Kirkland', 313);
INSERT INTO Cliente VALUES (214, 234567911, 'GarrettLane@gmail.com', 'Jornalista', 945612857,'Avenida 24 julho', 'Garrett Lane', 314);
INSERT INTO Cliente VALUES (215, 234567912, 'ElizaRusu@gmail.com', 'Empregada Doméstica', 935623549, 'Travessa Alcaide', 'Eliza Rusu', 315);
INSERT INTO Cliente VALUES (216, 234567913, 'JoyceMorais@gmail.com', 'Varredora de Rua', 937163812,'Rua D.Luis I', 'Joyce Morais', 316);
INSERT INTO Cliente VALUES (217, 234567914, 'BernardoAmado@gmail.com', 'Desempregado', 937672150, 'Travessa da Bela Vista', 'Bernardo Amado', 317);
INSERT INTO Cliente VALUES (218, 234567915, 'CariDaugherty2gmail.com', 'Empresário', 912393301, 'Rua Madres', 'Cari Daugherty', 318);
INSERT INTO Cliente VALUES (219, 234567916, 'CarrieBaxter@gmail.com', 'Engenheiro Civil', 916936289,'Avenida 24 Julho', 'Carrie Baxter', 319);
INSERT INTO Cliente VALUES (220, 234567917, 'WillFischer@gmail.com', 'Eletrecista', 901268345, 'Rua 10', 'Will Fischer', 320);
INSERT INTO Cliente VALUES (221, 234567918, 'LyndonHyde@gmail.com', 'Camionista', 983651234,'Rua 11', 'Lyndon Hyde', 321);
INSERT INTO Cliente VALUES (222, 234567919, 'HarisDunn@gmail.com', 'Programador', 984510420, 'Rua 12', 'Haris Dunn', 322);
INSERT INTO Cliente VALUES (223, 234567920, 'Julienweigl@gmail.com', 'Futebolista', 995255333,'Rua 13', 'Julien weigl', 323);
INSERT INTO Cliente VALUES (224, 234567921, 'Lebronjames@gmail.com', 'Basketbolista', 902000234, 'Rua 15', 'Lebron James', 324);
INSERT INTO Cliente VALUES (225, 234567923, 'CapriceOrtiz@gmail.com', 'Cozinheiro', 908920000, 'Rua João dos Santos', 'Caprice Ortiz', 325);
INSERT INTO Cliente VALUES (226, 234567924, 'TedShea@gmail.com', 'Psicologo', 993002002, 'Rua 18', 'Ted Shea', 326);
INSERT INTO Cliente VALUES (227, 234567925, 'KaysonHogan@gmail.com', 'Cartonista', 909909090, 'Rua José Luis Garcia Rodrigues', 'Kayson Hogan', 327);
INSERT INTO Cliente VALUES (228, 234567926, 'KennethGreig@gmail.com', 'Diplomata', 997782821,  'Rua Amoreiras à Ajuda', 'Kenneth Greig', 328);
INSERT INTO Cliente VALUES (229, 234567927, 'AshleeArcher@gmail.com', 'consultor Informático', 945981000, 'Rua Meio à Ajuda', 'Ashlee Archer', 329);





/*POPULATE COMPRA	*/					        

INSERT INTO Compra VALUES (800, 441, 215, '2019-04-18');
INSERT INTO Compra VALUES (801, 442, 215, '2019-11-21');
INSERT INTO Compra VALUES (802, 443, 217, '2020-01-04');
INSERT INTO Compra VALUES (803, 444, 201, '2019-12-15');
INSERT INTO Compra VALUES (804, 445, 223, '2020-01-08');
INSERT INTO Compra VALUES (805, 446, 224, '2018-07-17');
INSERT INTO Compra VALUES (806, 447, 212, '2019-11-22');
INSERT INTO Compra VALUES (807, 448, 208, '2019-05-18');
INSERT INTO Compra VALUES (808, 449, 209, '2019-11-22');
INSERT INTO Compra VALUES (809, 450, 217, '2019-02-28');
INSERT INTO Compra VALUES (810, 451, 222, '2019-04-25');
INSERT INTO Compra VALUES (811, 452, 212, '2017-12-22');
INSERT INTO Compra VALUES (812, 453, 211, '2017-10-13');
INSERT INTO Compra VALUES (813, 454, 212, '2017-12-22');
INSERT INTO Compra VALUES (814, 455, 229, '2018-12-02');
INSERT INTO Compra VALUES (815, 456, 207, '2019-06-04');
INSERT INTO Compra VALUES (816, 457, 228, '2018-04-11');
INSERT INTO Compra VALUES (817, 458, 214, '2017-03-24');
INSERT INTO Compra VALUES (818, 459, 206, '2019-10-25');
INSERT INTO Compra VALUES (819, 460, 202, '2019-11-22');
INSERT INTO Compra VALUES (820, 461, 217, '2017-09-20');
INSERT INTO Compra VALUES (821, 462, 216, '2018-08-13');
INSERT INTO Compra VALUES (822, 463, 227, '2019-04-24');
INSERT INTO Compra VALUES (823, 464, 208, '2019-06-04');
INSERT INTO Compra VALUES (824, 465, 222, '2019-02-24');
INSERT INTO Compra VALUES (825, 466, 201, '2018-01-14');
INSERT INTO Compra VALUES (826, 467, 217, '2019-07-17');
INSERT INTO Compra VALUES (827, 468, 208, '2019-04-19');
INSERT INTO Compra VALUES (828, 469, 216, '2017-01-11');
INSERT INTO Compra VALUES (829, 470, 215, '2018-06-23');
INSERT INTO Compra VALUES (830, 471, 227, '2017-11-18');
INSERT INTO Compra VALUES (831, 472, 203, '2019-11-20');
INSERT INTO Compra VALUES (832, 473, 210, '2020-01-10');
INSERT INTO Compra VALUES (833, 474, 203, '2020-01-9');
INSERT INTO Compra VALUES (834, 475, 217, '2019-02-27');
INSERT INTO Compra VALUES (835, 476, 218, '2018-03-12');
INSERT INTO Compra VALUES (836, 477, 221, '2019-04-09');
INSERT INTO Compra VALUES (837, 478, 224, '2018-06-27');
INSERT INTO Compra VALUES (838, 479, 213, '2019-08-02');
INSERT INTO Compra VALUES (839, 480, 222, '2019-08-15');
INSERT INTO Compra VALUES (840, 481, 221, '2018-05-18');
INSERT INTO Compra VALUES (841, 482, 211, '2019-01-11');
INSERT INTO Compra VALUES (842, 483, 215, '2017-10-19');
INSERT INTO Compra VALUES (843, 484, 214, '2018-03-24');
INSERT INTO Compra VALUES (844, 485, 224, '2019-03-16');
INSERT INTO Compra VALUES (845, 486, 206, '2019-04-01');
INSERT INTO Compra VALUES (846, 487, 216, '2018-12-11');
INSERT INTO Compra VALUES (847, 488, 212, '2019-07-21');
INSERT INTO Compra VALUES (848, 489, 226, '2019-10-10');
INSERT INTO Compra VALUES (849, 490, 227, '2017-01-26');
INSERT INTO Compra VALUES (850, 491, 207, '2018-05-05');
INSERT INTO Compra VALUES (851, 492, 209, '2019-09-01');
INSERT INTO Compra VALUES (852, 492, 200, '2019-04-08');
INSERT INTO Compra VALUES (853, 493, 201, '2019-01-02');
INSERT INTO Compra VALUES (854, 494, 202, '2019-02-02');
INSERT INTO Compra VALUES (855, 495, 203, '2018-03-03');
INSERT INTO Compra VALUES (856, 496, 204, '2019-04-04');
INSERT INTO Compra VALUES (857, 497, 205, '2018-05-05');
INSERT INTO Compra VALUES (858, 498, 206, '2019-06-06');
INSERT INTO Compra VALUES (859, 499, 207, '2019-07-07');
INSERT INTO Compra VALUES (860, 501, 208, '2019-08-08');
INSERT INTO Compra VALUES (861, 502, 209, '2019-09-09');
INSERT INTO Compra VALUES (862, 503, 210, '2019-10-10');
INSERT INTO Compra VALUES (863, 504, 211, '2019-11-11');
INSERT INTO Compra VALUES (864, 505, 212, '2018-12-12');
INSERT INTO Compra VALUES (865, 506, 213, '2019-02-17');
INSERT INTO Compra VALUES (866, 507, 229, '2019-03-28');
INSERT INTO Compra VALUES (867, 508, 201, '2019-04-30');
INSERT INTO Compra VALUES (868, 509, 215, '2019-08-18');
INSERT INTO Compra VALUES (869, 510, 216, '2019-11-21');
INSERT INTO Compra VALUES (870, 511, 219, '2018-12-25');
INSERT INTO Compra VALUES (871, 512, 220, '2019-10-20');
INSERT INTO Compra VALUES (872, 513, 213, '2019-07-08');
INSERT INTO Compra VALUES (873, 514, 214, '2019-06-26');
INSERT INTO Compra VALUES (874, 515, 215, '2018-11-29');
INSERT INTO Compra VALUES (875, 516, 216, '2019-04-14');
INSERT INTO Compra VALUES (876, 517, 217, '2019-09-01');
INSERT INTO Compra VALUES (877, 518, 218, '2018-01-19');
INSERT INTO Compra VALUES (878, 519, 219, '2019-11-22');
INSERT INTO Compra VALUES (879, 520, 220, '2018-04-09');
INSERT INTO Compra VALUES (880, 521, 221, '2019-01-22');
INSERT INTO Compra VALUES (881, 522, 222, '2019-11-20');
INSERT INTO Compra VALUES (882, 523, 223, '2018-11-23');
INSERT INTO Compra VALUES (883, 524, 224, '2019-01-24');
INSERT INTO Compra VALUES (887, 528, 228, '2018-11-11');
INSERT INTO Compra VALUES (888, 529, 229, '2019-05-01');
INSERT INTO Compra VALUES (889, 530, 214, '2018-02-14');
INSERT INTO Compra VALUES (890, 531, 212, '2018-06-08');
INSERT INTO Compra VALUES (891, 532, 204, '2019-09-16');
INSERT INTO Compra VALUES (892, 533, 201, '2018-09-07');
INSERT INTO Compra VALUES (893, 534, 201, '2019-06-01');
INSERT INTO Compra VALUES (894, 535, 203, '2019-03-09');



/*POPULATE VENDE */

INSERT INTO Vende VALUES (51, 800);
INSERT INTO Vende VALUES (53,801);
INSERT INTO Vende VALUES (52,802);
INSERT INTO Vende VALUES (51,803);
INSERT INTO Vende VALUES (52,804);
INSERT INTO Vende VALUES (51,805);
INSERT INTO Vende VALUES (52,806);
INSERT INTO Vende VALUES (53,807);
INSERT INTO Vende VALUES (52,808);
INSERT INTO Vende VALUES (53,809);
INSERT INTO Vende VALUES (51,810);
INSERT INTO Vende VALUES (53,811);
INSERT INTO Vende VALUES (52,812);
INSERT INTO Vende VALUES (51,813);
INSERT INTO Vende VALUES (51,814);
INSERT INTO Vende VALUES (52,815);
INSERT INTO Vende VALUES (53,816);
INSERT INTO Vende VALUES (52,817);
INSERT INTO Vende VALUES (51,818);
INSERT INTO Vende VALUES (53,819);
INSERT INTO Vende VALUES (51,820);
INSERT INTO Vende VALUES (52,821);
INSERT INTO Vende VALUES (53,822);
INSERT INTO Vende VALUES (53,823);
INSERT INTO Vende VALUES (52,824);
INSERT INTO Vende VALUES (53,825);
INSERT INTO Vende VALUES (51,826);
INSERT INTO Vende VALUES (52,827);
INSERT INTO Vende VALUES (53,828);
INSERT INTO Vende VALUES (52,829);
INSERT INTO Vende VALUES (52,830);
INSERT INTO Vende VALUES (53,831);
INSERT INTO Vende VALUES (51,832);
INSERT INTO Vende VALUES (52,833);
INSERT INTO Vende VALUES (53,834);
INSERT INTO Vende VALUES (51,835);
INSERT INTO Vende VALUES (51,836);
INSERT INTO Vende VALUES (52,837);
INSERT INTO Vende VALUES (53,838);
INSERT INTO Vende VALUES (51,839);
INSERT INTO Vende VALUES (52,840);
INSERT INTO Vende VALUES (53,841);
INSERT INTO Vende VALUES (52,842);
INSERT INTO Vende VALUES (52,843);
INSERT INTO Vende VALUES (53,841);
INSERT INTO Vende VALUES (52,842);
INSERT INTO Vende VALUES (53,843);
INSERT INTO Vende VALUES (51,844);
INSERT INTO Vende VALUES (51,845);
INSERT INTO Vende VALUES (52,846);
INSERT INTO Vende VALUES (52,847);
INSERT INTO Vende VALUES (53,848);
INSERT INTO Vende VALUES (53,849);
INSERT INTO Vende VALUES (52,850);
INSERT INTO Vende VALUES (53,851);
INSERT INTO Vende VALUES (51,852);
INSERT INTO Vende VALUES (51,853);
INSERT INTO Vende VALUES (52,854);
INSERT INTO Vende VALUES (53,855);
INSERT INTO Vende VALUES (51,856);
INSERT INTO Vende VALUES (51,857);
INSERT INTO Vende VALUES (53,858);
INSERT INTO Vende VALUES (52,859);
INSERT INTO Vende VALUES (52,860);
INSERT INTO Vende VALUES (53,861);
INSERT INTO Vende VALUES (51,862);
INSERT INTO Vende VALUES (53,863);
INSERT INTO Vende VALUES (52,864);
INSERT INTO Vende VALUES (53,865);
INSERT INTO Vende VALUES (51,866);
INSERT INTO Vende VALUES (52,867);
INSERT INTO Vende VALUES (52,868);
INSERT INTO Vende VALUES (53,869);
INSERT INTO Vende VALUES (52,870);
INSERT INTO Vende VALUES (51,871);
INSERT INTO Vende VALUES (52,872);
INSERT INTO Vende VALUES (53,873);
INSERT INTO Vende VALUES (51,874);
INSERT INTO Vende VALUES (52,875);
INSERT INTO Vende VALUES (52,876);
INSERT INTO Vende VALUES (51,877);
INSERT INTO Vende VALUES (53,878);
INSERT INTO Vende VALUES (52,879);
INSERT INTO Vende VALUES (51,880);
INSERT INTO Vende VALUES (52,881);
INSERT INTO Vende VALUES (52,882);
INSERT INTO Vende VALUES (51,883);
INSERT INTO Vende VALUES (52,887);
INSERT INTO Vende VALUES (52,888);
INSERT INTO Vende VALUES (51,889);
INSERT INTO Vende VALUES (53,890);
INSERT INTO Vende VALUES (53,891);
INSERT INTO Vende VALUES (52,892);
INSERT INTO Vende VALUES (52,893);
INSERT INTO Vende VALUES (51,894);

