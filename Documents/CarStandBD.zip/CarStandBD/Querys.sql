/* CarStand
	Elementos da Equipa:
		-Bernardo Antunes: 50037271
        -Bernardo Branco: 50039074
*/

/*ASSOCIA O CODIGO POSTAL AO CLIENTE -*/
SELECT CL.CL_Nome as Nome, CP.CP_4D as 4D , CP.CP_3D as 3D, CP.CP_Concelho as Freguesia
FROM Cliente CL, Código_Postal CP
WHERE CL.ID_CodPost = CP.ID_CodPost
order by Nome;

/*Número de carros disponiveis no STAND e o seu valor' -*/
SELECT ST.ST_Nome as Stand, count(C.Car_Estado) as 'Total Carros Disponíveis', sum(C.Car_Preço) as Total€
FROM Stand ST, Carro C
WHERE C.Car_Estado = 'Disponivel';
/*Listagem do Número de carros comprados por cada cliente +-*/
SELECT C.CL_Nome AS 'Nome', COUNT(CO.ID_Compra) AS 'TOTAL'
FROM Compra CO, Cliente C
where C.ID_Cliente = CO.ID_Cliente
group by Nome
ORDER BY TOTAL DESC;

/*LISTAGEM DO TOTAL DE CARROS COMPRADO POR CATEGORIA E A SUA REPRESENTAÇÃO MONETÁRIA*/
SELECT C.Car_Categoria AS Categoria, count(C.ID_Car) AS 'Total_Carro', sum(C.Car_Preço) as Total€
FROM Carro C, Compra CO
where C.ID_Car = CO.ID_Car
GROUP BY Categoria;


/*Devolve os codigos postais com mais carros comprados de determinada marca*/
SELECT  Carro.Car_Marca as marca, s1.N, s1.CP  FROM (
    SELECT Co.ID_Car AS car, (s2.n) AS N , s2.cp4 AS CP FROM (SELECT COUNT(Cl.ID_Cliente) AS n, Cl.ID_Cliente AS id, CP.CP_4D as cp4 FROM Cliente AS Cl 
    INNER JOIN Código_Postal AS CP ON Cl.ID_CodPost = CP.ID_CodPost GROUP BY cp4) AS s2 INNER JOIN Compra AS Co WHERE s2.id = Co.ID_Cliente) as s1

INNER JOIN Carro ON s1.car = Carro.ID_Car WHERE Carro.Car_Marca LIKE 'Audi'
GROUP BY s1.CP;

/*Colaborador com mais carros vendidos e o total das vendas deste em termos monetátios*/
SELECT  CB.Col_Nome, s1.Vendas, s1.Total FROM(
SELECT V.NMEC as id, SUM(Carro.Car_Preço) AS Total, COUNT(Carro.Car_Preço) AS Vendas FROM (Compra AS C INNER JOIN Vende AS V ON V.ID_Compra = C.ID_Compra )
INNER JOIN Carro ON C.ID_Car = Carro.ID_Car WHERE C.ID_Car = Carro.ID_Car AND V.NMEC = (SELECT  id
FROM (
    SELECT  COUNT(V.NMEC) AS TOTAL, CB.Col_Nome AS NOME, V.NMEC as id
    FROM Colaborador CB, Vende V
    WHERE CB.NMEC = V.NMEC 
    GROUP BY CB.NMEC
    ORDER BY count(CB.NMEC) DESC) AS NW
    LIMIT 1)
    GROUP BY V.NMEC) AS s1 INNER JOIN Colaborador AS CB ON s1.id = CB.NMEC ;