/* CarStand
	Elementos da Equipa:
		-Bernardo Antunes: 50037271
        -Bernardo Branco: 50039074
*/



/*Lista de drops das Tabelas */
DROP TABLE Vende;
DROP TABLE Compra;
DROP TABLE Colaborador;
DROP TABLE Stand;
DROP TABLE Cliente;
DROP TABLE Código_Postal; 
DROP TABLE Carro;




/*Lista de tabelas primárias*/

/*Criar Tabela Carro*/
CREATE TABLE `Carro` (
  `ID_Car` 			int PRIMARY KEY ,
  `Car_Marca` 		varchar(100)  NOT NULL,
  `Car_Modelo` 		varchar(50)  NOT NULL,
  `Car_Cilindrada` 	char(5)  NOT NULL CHECK (Car_Cilindrada > 100 AND Car_Cilindrada < 10000) ,
  `Car_Preço` 		char(7) NOT NULL CHECK (Car_Preço > 100 AND Car_Preço < 16000000),
  `Car_Ano` 		char(4)  NOT NULL CHECK (Car_Ano > 1950 AND Car_Ano < 2021),
  `Car_Categoria` 	varchar(70)  NOT NULL,
  `Car_Matrícula` 	varchar(20) NOT NULL CHECK (length(Car_Matrícula) = 8),
  `Car_Combustivel` char(49) NOT NULL,
   `Car_Estado` ENUM('Disponivel', 'Reservado', 'Vendido') DEFAULT 'Disponivel');
  
  /*Criar Tabela Código Postal*/
  CREATE TABLE `Código_Postal` (
	`ID_CodPost` 	int PRIMARY KEY,
	`CP_Freg` 		varchar(100) NOT NULL,
	`CP_3D` 		char(3) NOT NULL CHECK( LENGTH(CP_3D) = 3),
	`CP_4D` 		char(4) NOT NULL CHECK( LENGTH(CP_4D) = 4), 
	`CP_Concelho` 	varchar(100) NOT NULL);
  
  /*Criar Table Cliente*/
  CREATE TABLE `Cliente` (
  `ID_Cliente` 		int PRIMARY KEY, 
  `CL_NIF` 			char(9) NOT NULL CHECK  (LENGTH(CL_NIF) = 9),
  `CL_Email` 		varchar(250) NOT NULL,
  `CL_Profissão` 	varchar(250) NOT NULL,
  `CL_NTelemóvel` 	char(9) NOT NULL CHECK( LENGTH(CL_NTelemóvel) = 9),
  `CL_Morada` 		varchar(250) NOT NULL,
  `CL_Nome` 		varchar(70)	NOT NULL,
  `ID_CodPost`		int,
   FOREIGN KEY (ID_CodPost) REFERENCES Código_Postal(ID_CodPost));
   
  /*Criar Tabela Stand*/ 
   CREATE TABLE `Stand` (
  `ID_Stand` 		int PRIMARY KEY,
  `ST_Nome`			varchar(30), 		
  `ST_Email` 		varchar(250) NOT NULL,
  `ST_NTelefone` 	char(14) NOT NULL CHECK( LENGTH(ST_NTelefone) = 9),
  `ST_NIF` 			char(9) NOT NULL CHECK( LENGTH(ST_NIF) = 9),
  `ST_Morada` 		varchar(250) NOT NULL,
  `ID_CodPost`		int,
   FOREIGN KEY (ID_CodPost) REFERENCES Código_Postal(ID_CodPost)); 
   
   
   /*Criar Tabila Stand*/
   CREATE TABLE `Colaborador` (
  `NMEC` 		int PRIMARY KEY,
  `Col_Nome` 	varchar(100)  NOT NULL,
  `ID_Stand`	int,
 FOREIGN KEY (ID_Stand) REFERENCES Stand(ID_Stand));
 
 
/* Lista de tabelas secundaria */

 /*Criar Tabela Compra*/  
CREATE TABLE `Compra` (
  `ID_Compra`		int PRIMARY KEY,
  `ID_Car`			int,
  `ID_Cliente`		int,
  `Data`			date,
   FOREIGN KEY (ID_Car) REFERENCES Carro(ID_Car),
   FOREIGN KEY (ID_Cliente) REFERENCES Cliente(ID_Cliente));
   
 /*Criar Tabela Vende*/  
CREATE TABLE `Vende` (
  `NMEC` int,
  `ID_Compra` int,
  FOREIGN KEY (ID_Compra) REFERENCES Compra(ID_Compra),
  FOREIGN KEY (NMEC) REFERENCES Colaborador(NMEC));
  